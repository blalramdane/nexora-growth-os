# NEXORA — COMPANY AI BRAIN
## Master Company / Product / Strategy / Operations Reference
### Version 1.0

> هذا الملف مخصص لمشروع **«شركتي»**، والمقصود به شركة **Nexora**.
> الهدف منه أن يعمل ChatGPT داخل المشروع كـCompany Brain متصل، وليس كمساعد منفصل لكل محادثة.

---

# 1. ما هي Nexora؟

Nexora هي شركة/منصة تقنية هدفها بناء حلول رقمية عملية للشركات والأنشطة التجارية، مع التركيز على:

- Websites
- Web Applications
- Business Management Systems
- Dashboards
- Mobile Applications
- System Integration
- APIs / Webhooks
- Automation
- AI-powered business solutions

الفكرة الأساسية ليست بيع «كود» فقط، بل تحويل مشاكل الشركات إلى منتجات وأنظمة قابلة للاستخدام والتوسع.

---

# 2. فلسفة الشركة

Nexora يجب أن تُبنى كشركة **Product + Technology + Business Solutions**.

المبدأ:

BUSINESS PROBLEM
→ PRODUCT / SYSTEM
→ DESIGN
→ DEVELOPMENT
→ DEPLOYMENT
→ OPERATIONS
→ IMPROVEMENT

لا يتم التعامل مع المشروع على أنه Website فقط أو App فقط.

كل عميل يجب أن يُفهم من ناحية:
- المشكلة
- المستخدم
- العمليات
- البيانات
- المبيعات
- التشغيل
- التقنية
- القياس

---

# 3. السوق المستهدف

الفئات التي ظهرت في استراتيجية الشركة:

### Restaurants / Cafes / F&B
- Websites
- Digital menus
- QR ordering
- POS / operating systems
- CRM
- WhatsApp workflows
- Automation

### Companies / SMEs
- Websites
- Dashboards
- Management systems
- CRM
- Internal tools
- Automation
- Integrations

### Clinics
- Websites
- Booking/management systems
- Patient-facing digital experiences
- CRM/communication
- Automation

### Retail / Distribution
- E-commerce
- Inventory
- Sales
- Suppliers
- Warehouses
- Distribution
- Field/mobile sales

### Home Appliances / Electrical Tools
هذا قطاع مهم في استراتيجية الشركة بسبب وجود معرفة مباشرة بالسوق وقاعدة تواصل مع أصحاب المحلات.

---

# 4. Strategic Advantage

من أهم الأصول الاستراتيجية المتاحة للشركة:

- خبرة عملية في بناء Business Systems.
- خبرة Laravel/PHP وFull-Stack.
- خبرة في e-commerce.
- خبرة في Restaurant/POS systems.
- خبرة في inventory/distribution.
- فهم عملي لاحتياجات الشركات المصرية.
- معرفة مباشرة بقطاع الأجهزة المنزلية والكهربائية.
- قاعدة تواصل تقارب 2000 رقم لأصحاب محلات في هذا القطاع وفق مشروع SaaS السابق.
- إمكانية استخدام AI لتسريع البحث والتطوير والإنتاج.

هذه ليست مجرد مهارات تقنية؛ يمكن تحويلها إلى **vertical solutions** متخصصة.

---

# 5. الشركة ليست منتجًا واحدًا

يجب فصل:

## Company
Nexora

## Products
منتجات SaaS مثل:
- Nexora QR
- Whats360
- منتجات مستقبلية

## Client Services
- Websites
- Apps
- Business systems
- Integrations
- Automation
- AI solutions

## Internal Platform
الأدوات والـAI والـprocesses التي تستخدمها Nexora داخليًا لإنتاج وتسليم المشاريع.

---

# 6. Nexora QR

Nexora QR هو أحد المنتجات الأساسية التي تم تطوير تصور معماري مفصل لها.

ليس مجرد QR Menu.

المنتج الحقيقي:

**Multi-tenant SaaS لإدارة التجربة الرقمية والطلب للمطعم.**

يتكون من:

1. Customer Menu / Ordering
2. Restaurant Dashboard
3. Nexora Admin
4. Design System
5. WhatsApp layer

---

# 7. مشكلة Nexora QR

المطاعم غالبًا أمام خيارات مثل:

- Menu ورقية
- PDF داخل QR
- حلول QR متشابهة
- حلول لا تعكس هوية المطعم
- حلول لا تحتوي على Ordering حقيقي
- أنظمة منفصلة وغير مترابطة

Nexora QR يستهدف جمع:

DESIGN
+
MENU
+
ORDERING
+
DASHBOARD
+
WHATSAPP

في منتج واحد.

---

# 8. Nexora QR — القيمة الأساسية

الفكرة:

**منيو تبدو وكأنها صُممت خصيصًا لهذا المطعم، مع نظام طلب حقيقي، بدون الحاجة لمصمم أو مطور داخل المطعم.**

الميزة الجوهرية في المنتج:

**Design is a Product Feature**

أي أن التصميم ليس مجرد Theme لتغيير اللون، بل Design System حقيقي.

---

# 9. Nexora QR — المستخدمون

### Primary
أصحاب مطاعم/كافيهات صغيرة ومتوسطة، خصوصًا 1–3 فروع.

### Secondary
العميل النهائي الذي يمسح QR ويطلب.

### Internal
فريق Nexora الذي يدير:
- Templates
- Restaurants
- Support
- Onboarding
- Design

---

# 10. Nexora QR — Design System

البنية المقترحة:

Design Tokens
↓
Template
↓
Template Version
↓
Restaurant Theme Instance
↓
Restaurant Content

ويجب الفصل الكامل بين:

DESIGN
و
CONTENT

تغيير Template لا يجب أن يغيّر:
- Products
- Prices
- Categories
- Orders
- Restaurant data

---

# 11. Template Versioning

كل Template له Versions.

مثال:

Template A
- V1
- V2
- V3

النسخة المنشورة تكون immutable.

المطعم يرتبط بـTemplate Version محددة.

إذا تم تحديث التصميم:
- لا يتم الكتابة فوق القديم.
- يتم إنشاء Version جديدة.
- المطاعم القديمة لا تتأثر تلقائيًا.

Rollback = تغيير المرجع للنسخة السابقة.

---

# 12. Menu Builder

الـFlow المستهدف:

Create Restaurant
→ Choose Design
→ Brand Setup
→ Categories
→ Products
→ Modifiers
→ Tables / QR
→ Preview
→ Publish

يجب دعم:
- Bulk product entry
- Categories
- Products
- Variants
- Modifier Groups
- Images
- Availability
- Draft/Live
- Preview

---

# 13. Customer UX — QR

الرحلة الأساسية:

Scan QR
→ Menu
→ Categories
→ Product
→ Modifiers
→ Cart
→ Checkout
→ Confirmation
→ Tracking

بدون إجبار العميل على إنشاء حساب.

### Dine-in
المطعم والفرع والطاولة معروفون من QR.

### Pickup
اسم + WhatsApp.

### Delivery
بيانات التوصيل المطلوبة فقط.

---

# 14. Nexora QR — MVP

داخل MVP:

- Multi-tenancy
- Restaurants
- Branches
- Users
- Owner role
- 2–3 high-quality templates
- Menu Builder
- Categories
- Products
- Variants
- Modifier Groups
- Dynamic QR
- Preview
- PNG/PDF/Print
- Dine-in
- Pickup
- Delivery
- Orders
- Order state machine
- Order history
- Tracking
- Restaurant Dashboard
- Menu management
- Branding settings
- QR management
- Nexora Admin
- Logged impersonation
- Activity logs
- Arabic RTL
- WhatsApp via `wa.me`

---

# 15. المؤجل في Nexora QR

ليس في MVP:

- Official WhatsApp Business API
- Online payment
- Advanced staff roles
- Advanced analytics
- AI recommendations
- Multi-branch public selector
- Reorder
- Feedback
- Billing/subscriptions activation
- Custom domains
- Full English activation
- No-code template marketplace

---

# 16. Nexora QR — Roadmap

## Phase 1
Pilot 5–10 restaurants.

الهدف:
- تشغيل حقيقي
- قياس الاستخدام
- اكتشاف مشاكل UX
- التأكد من PMF

## Phase 2
- WhatsApp Business API
- Manager/Cashier/Kitchen roles
- KDS
- Analytics
- Heatmaps
- Reorder
- Feedback
- Multi-branch
- Billing
- 5–8 templates إضافية

## Phase 3
- Payments
- Recommendations
- English
- Gulf expansion
- Custom domains
- Template A/B testing
- Design marketplace

## Future
- No-code Template Builder
- Loyalty
- POS integrations
- Demand forecasting

---

# 17. Whats360

Whats360 هو منتج/منصة WhatsApp CRM & Sales Management ضمن استراتيجية Nexora.

المكونات التي تم تصورها:

- Shared Inbox
- CRM
- AI Chatbot
- Bulk Messaging
- WhatsApp API
- Webhooks
- Automation
- Sales workflows

الفكرة:
تحويل WhatsApp من مجرد chat إلى **Business Operating Channel**.

---

# 18. Whats360 — Core Architecture

Conceptual flow:

WhatsApp
→ Inbox
→ Contact
→ CRM
→ Conversation
→ Automation
→ AI
→ Sales
→ Analytics

المنتج يجب أن يفصل:
- Messaging
- Contacts
- CRM
- Automation
- AI
- Sales
- Analytics

حتى لا يتحول النظام إلى chat UI فقط.

---

# 19. WhatsApp Rules

في Nexora QR، القرار المعماري الحالي:

### MVP
`wa.me`

السبب:
- أقل تكلفة
- أقل تعقيد
- لا يحتاج WhatsApp API setup
- مناسب للتحقق من المنتج

### Phase 2
Official WhatsApp Business API / BSP.

الخيارات التي تمت مناقشتها:
- Meta Cloud API
- 360dialog
- Twilio
- Gupshup

يجب عدم بناء المنتج الجاد على WhatsApp Web automation غير الرسمي.

---

# 20. Company Service Model

Nexora يمكن أن تعمل بثلاثة مسارات:

### 1. Build
نطور النظام للعميل.

### 2. Productize
نحوّل الحل المتكرر إلى SaaS.

### 3. Operate
نساعد العميل في التشغيل والتحسين والـautomation.

الهدف طويل المدى:
تقليل الاعتماد على مشاريع custom فقط وزيادة المنتجات القابلة للتكرار.

---

# 21. أول Vertical عملي

قطاع الأجهزة المنزلية والكهربائية له أهمية خاصة.

الخلفية:
- معرفة مباشرة بالسوق.
- وجود محل عائلي كبير يغطي المدينة.
- قاعدة تواصل تقارب 2000 صاحب محل.
- الرغبة في الوصول مباشرة لأصحاب المحلات.

الاستراتيجية المطروحة:
بدل بيع SaaS بطريقة عامة من البداية، بناء حل قوي لقطاع الأجهزة ثم الحصول على عميل/محل مرجعي قوي واستخدام نجاحه كـProof.

---

# 22. SaaS للأجهزة المنزلية والكهربائية

الفكرة:
أداة SaaS/Automation موجهة لأصحاب محلات الأجهزة المنزلية والكهربائية.

يمكن أن تدور حول:
- Products
- Inventory
- Sales
- Customers
- Suppliers
- Orders
- Reporting
- Automation
- Digital presence

لكن يجب عدم تثبيت Feature list نهائية قبل Validation مع العملاء.

---

# 23. استراتيجية العملاء الأولى

المبدأ:
لا نبدأ ببيع منتج generic للجميع.

نبدأ من Vertical نفهمه جيدًا.

مثال:

Home Appliances / Electrical Tools
→ 1 strong pilot
→ measurable results
→ case study
→ repeatable package
→ more stores

هذا يجعل المنتج مبنيًا على مشكلة حقيقية بدل التخمين.

---

# 24. Websites كخدمة

Website service يجب ألا تكون:
"نعمل لك موقع وخلاص."

بل:

Discovery
→ Brand understanding
→ UX
→ Design
→ Development
→ Content
→ SEO basics
→ Analytics
→ Deployment
→ Maintenance

ويمكن تحويل المواقع المتكررة إلى Templates/vertical packages لتقليل وقت التنفيذ.

---

# 25. Apps

Nexora تستطيع تنفيذ:
- Customer apps
- Business apps
- Mobile dashboards
- API-connected Flutter apps

ولكن لا يجب بناء Mobile App عندما يكون Web/PWA كافيًا.

اختيار التقنية يكون بناءً على:
- المستخدم
- الاستخدام
- Offline requirements
- Device capabilities
- تكلفة الصيانة

---

# 26. Business Systems

هذه من أقوى مناطق Nexora.

أمثلة من الخبرة/المشاريع:

### Restaurant
- POS
- Orders
- Tables
- Kitchen
- Inventory
- Users
- Reports

### Distribution
- Warehouse
- Inventory
- Suppliers
- Invoices
- Vehicle stock
- Mobile sales
- Multi-location

### E-commerce
- Products
- Orders
- Customers
- APIs
- Admin

هذا يجب تحويله إلى Knowledge Base داخل الشركة، وليس مجرد مشاريع منفصلة.

---

# 27. التقنية

المكدس العملي المتكرر:

Backend:
- PHP
- Laravel
- REST APIs
- Sanctum
- Webhooks

Frontend:
- Next.js
- React
- TypeScript
- Tailwind CSS

Mobile:
- Flutter
- Dio
- Riverpod

Databases:
- MySQL
- SQLite عند الحاجة إلى Local-first

Infrastructure:
- Git/GitHub
- Cloud hosting
- CDN
- Redis عند الحاجة
- S3-compatible storage

---

# 28. Engineering Philosophy

لا نعيد بناء ما يعمل بدون سبب.

Laravel هو الاختيار الأساسي للـBackend في المشاريع الحالية التي تعتمد عليه.

القرارات التقنية يجب أن تبنى على:
- Business requirements
- Reliability
- Maintainability
- Cost
- Team capability
- Scalability

وليس على الموضة التقنية.

---

# 29. Restaurant System Architecture Reference

الخبرة الحالية تشمل نظام Restaurant Operating System/POS يحتوي على:

- POS
- Cashier
- Orders
- Tables
- Kitchen
- Inventory
- Permissions
- Dashboards
- Invoices
- Receipts
- Offline/local-first architecture
- Reliable order handling

وهذه الخبرة يمكن تحويلها إلى accelerator لمشاريع F&B المستقبلية.

---

# 30. AI Strategy

AI في Nexora ليس Feature للعرض.

يستخدم في:

### Internal
- Research
- Requirements analysis
- Documentation
- Coding
- Testing
- Debugging
- Marketing
- Content
- Client communication
- Knowledge retrieval

### Client Products
- Chatbots
- Automation
- Search
- Summaries
- Recommendations بعد توفر البيانات
- Customer support

القاعدة:
AI يجب أن يحل مشكلة حقيقية أو يقلل تكلفة/وقت.

---

# 31. AI Company Brain

داخل مشروع «شركتي» يجب أن يكون ChatGPT قادرًا على ربط:

Company
↓
Products
↓
Clients
↓
Projects
↓
Technology
↓
Marketing
↓
Sales
↓
Operations
↓
Knowledge
↓
Decisions

ولا يعيد سؤال المستخدم عن معلومات موجودة في المشروع.

---

# 32. Knowledge Base

يجب تقسيم المعرفة إلى:

## Company
- Positioning
- Services
- Team
- Policies

## Products
- Nexora QR
- Whats360
- Future products

## Clients
- Client profile
- Requirements
- Project
- Communication
- Deliverables

## Projects
- Scope
- Code
- Docs
- Decisions
- Bugs
- Deployments

## Marketing
- Posts
- Ads
- Campaigns
- Competitors
- Content ideas

## Research
- Competitors
- Market
- Tools
- Technologies

## Decisions
- Approved
- Rejected
- Superseded
- Pending

---

# 33. Marketing System

المحتوى يجب أن يبني:

AWARENESS
→ TRUST
→ PROOF
→ LEAD
→ SALES

Content pillars:
- Problems
- Solutions
- Case studies
- Product demos
- Before/after
- Educational
- Industry insights
- Product updates
- Client results

لا يتم تكرار نفس Post angle في محادثات مختلفة إذا كان موجودًا بالفعل.

---

# 34. Competitor Research

صفحات المنافسين تستخدم كـReference لتحليل:

- Hooks
- Headlines
- Services
- Pain points
- Solutions
- Reels
- Content angles
- Offers
- UX
- Positioning

ممنوع نسخ:
- النصوص
- الهوية
- التصميم
- Brand voice

نأخذ principle ونبني نسخة Nexora.

---

# 35. Sales System

Pipeline:

LEAD
→ QUALIFICATION
→ DISCOVERY
→ PROPOSAL
→ NEGOTIATION
→ CONTRACT
→ DEVELOPMENT
→ DELIVERY
→ SUPPORT
→ RETENTION
→ REFERRAL

كل Lead يجب أن يكون له:
- Source
- Industry
- Problem
- Budget range
- Decision maker
- Next action
- Status
- Owner

---

# 36. Proposal System

كل Proposal يجب أن يوضح:

- Client problem
- Current situation
- Proposed solution
- Scope
- Deliverables
- Timeline
- Technology where relevant
- Responsibilities
- Exclusions
- Commercial terms
- Next step

لا نبيع Features فقط.
نبيع Outcome + System.

---

# 37. Delivery System

بعد إغلاق العميل:

Discovery
→ Requirements
→ Scope Lock
→ UX/UI
→ Architecture
→ Development
→ QA
→ Client Review
→ Deployment
→ Handover
→ Support

كل مرحلة لها Definition of Done.

---

# 38. Project Memory

لكل مشروع يجب تسجيل:

- What was requested
- What was approved
- What was rejected
- Why a decision was made
- Current version
- Known bugs
- Pending items
- Deployment state
- Client feedback

لا تعاد القرارات القديمة وكأنها جديدة.

---

# 39. Product Memory

كل Product يجب أن يكون له:

- Vision
- Problem
- Target user
- Features
- Roadmap
- Architecture
- Current status
- Known risks
- Metrics
- Decisions
- Competitors
- Marketing assets

---

# 40. Brand / Design Memory

إذا تم اعتماد:
- Logo
- Color
- UI
- Template
- Post style
- Website section
- Campaign direction

فإنه يصبح Approved Reference حتى يتم تغييره صراحة.

لا يتم تعديل approved design تلقائيًا.

---

# 41. Versioning

استخدم:

V1
V2
V3

ولا تستبدل النسخة القديمة.

الحالات:

DRAFT
→ REVIEW
→ APPROVED
→ CURRENT
→ SUPERSEDED
→ ARCHIVED

---

# 42. Team

Nexora تحتاج تدريجيًا إلى أدوار واضحة:

- Founder / Product Lead
- Backend
- Frontend
- UI/UX
- QA
- Sales
- Marketing
- Client Success
- DevOps عند الحاجة

في البداية يمكن أن يكون الشخص الواحد مسؤولًا عن أكثر من Role.

لكن الـRole نفسه يجب أن يكون واضحًا.

---

# 43. Company Growth Model

النمو المقترح:

SERVICE
→ REPEATED SERVICE
→ PRODUCTIZED SERVICE
→ SaaS
→ MULTI-VERTICAL PRODUCTS

مثال:

Restaurant Website
→ Restaurant Website Package
→ QR Menu
→ Restaurant Operating Platform

مثال آخر:

WhatsApp setup
→ CRM workflow
→ Whats360
→ SaaS platform

---

# 44. Gulf Expansion

هناك توجه للتوسع إلى:
- Saudi Arabia
- Gulf

مع إمكانية استخدام:
- Authorized agents
- Local partners
- Resellers

عند دخول سوق جديد يجب دراسة:
- Legal
- Licensing
- Tax
- Pricing
- Competition
- Local support
- Partnerships
- Localization

لا يتم افتراض أن السوق المصري = السوق الخليجي.

---

# 45. Company Website

موقع Nexora يجب أن يبيع الشركة، وليس فقط يعرض خدمات تقنية.

يجب أن يوضح:

WHO WE ARE
WHAT WE BUILD
WHO WE HELP
WHAT WE SOLVE
OUR PRODUCTS
OUR SERVICES
OUR WORK
HOW WE WORK
CONTACT

ويجب الفصل بصريًا بين:
PRODUCTS
و
SERVICES

---

# 46. Product Portfolio

المنتجات الحالية/الاستراتيجية التي يجب أن يعرفها AI:

### Nexora QR
Restaurant digital menu + ordering SaaS.

### Whats360
WhatsApp CRM / sales / automation platform.

### Future Vertical SaaS
خصوصًا solutions للأجهزة المنزلية والكهربائية والقطاعات التي يتم Validation لها.

---

# 47. Important Existing Technical Evidence

المشروع يحتوي على أدلة مرتبطة بتطوير Nexora QR، ومنها:
- Laravel backend
- API architecture
- Public menu
- Tenant isolation tests
- Restaurant/category/product relationships
- Dashboard/admin concepts
- Ordering flows
- Design System decisions

هناك أيضًا سجلات أخطاء واختبارات فاشلة مرتبطة بالتطوير، مثل خطأ في `Restaurant::categories()` داخل PublicMenuController.

هذه السجلات تعتبر:
DEBUG HISTORY
وليست Product Requirements.

---

# 48. Engineering QA Rules

قبل اعتبار Feature مكتملة:

1. Functional test
2. Authorization test
3. Tenant isolation test
4. Validation test
5. Edge case test
6. UI test عند الحاجة
7. Regression test
8. Deployment check

في Multi-tenant systems:
أي endpoint يجب أن يُختبر ضد الوصول إلى Tenant آخر.

---

# 49. Security

أولوية:

- Authentication
- Authorization
- Tenant isolation
- Role permissions
- Secure file uploads
- Rate limiting
- Audit logs
- Admin impersonation logs
- Session expiry
- Webhook verification
- Secrets management

---

# 50. Business Metrics

على مستوى الشركة:

- Leads
- Qualified leads
- Conversion
- Revenue
- Average project value
- Project margin
- Delivery time
- Retention
- Referrals
- Product MRR
- Active SaaS customers

على مستوى Nexora QR:

- QR scans
- Menu views
- Product views
- Add to cart
- Checkout
- Completed orders
- Conversion
- AOV
- Cancellation
- Fulfillment time
- Active restaurants
- Time to first order
- Time to publish

---

# 51. What NOT to do

لا:

- نبني Features لمجرد أنها AI.
- نبدأ Marketplace قبل إثبات المنتج.
- نوسع الـMVP بلا validation.
- نستخدم WhatsApp automation غير رسمي في منتج جاد.
- نخلط Company identity مع Product identity.
- نخلط Client data بين العملاء.
- ننسخ المنافسين.
- نعتبر كل فكرة قديمة قرارًا حاليًا.
- نعيد سؤال المستخدم عن معلومات موجودة.
- نغير approved architecture بدون سبب واضح.
- نبني نظامًا ضخمًا قبل إثبات القيمة.

---

# 52. Decision Hierarchy

عند وجود تعارض:

1. أحدث قرار صريح من المستخدم
2. أحدث قرار Approved داخل المشروع
3. Product/Company source of truth
4. Project documentation
5. Previous conversations
6. General best practices

المعلومة الأحدث والمعتمدة تتغلب على القديمة.

---

# 53. AI Working Mode

عندما يطلب المستخدم تنفيذ شيء واضح:
EXECUTE.

عندما يوجد نقص حقيقي:
اسأل عن أقل معلومة ممكنة.

عندما يكون هناك أكثر من طريق:
اعرض الخيارات مع:
- Difference
- Cost
- Risk
- Impact
- Recommended next action based on documented project goals

ولا تعيد شرح كل تاريخ المشروع في كل مرة.

---

# 54. Company Operating Loop

أي قرار مهم يمر عبر:

CURRENT STATE
→ PROBLEM
→ EVIDENCE
→ OPTIONS
→ TRADE-OFFS
→ DECISION
→ IMPLEMENTATION
→ TEST
→ MEASURE
→ LEARN
→ UPDATE COMPANY BRAIN

---

# 55. Master Principle

Nexora ليست مجرد شركة برمجة.

Nexora يجب أن تكون **شركة تبني أنظمة ومنتجات رقمية تحل مشاكل حقيقية للشركات، وتحوّل الحلول المتكررة إلى منتجات قابلة للتوسع.**

الهدف النهائي:

CLIENT PROBLEM
→ NEXORA SOLUTION
→ REPEATABLE SYSTEM
→ PRODUCT
→ SCALE

---

# 56. CURRENT OPEN DECISIONS

يجب تحديث هذه القائمة كلما اتخذ المستخدم قرارًا:

- Final company positioning
- Final brand identity
- Official service packages
- Product portfolio
- Nexora QR pricing
- Whats360 scope
- First vertical SaaS
- Team structure
- Sales process
- Marketing system
- Website
- CRM
- Gulf expansion model
- Legal/company structure

---

# 57. SOURCE OF TRUTH RULE

أي ملف جديد يدخل مشروع «شركتي» يجب تصنيفه:

COMPANY
PRODUCT
CLIENT
PROJECT
MARKETING
RESEARCH
REFERENCE
DECISION
ARCHIVE

ولا يجوز للـAI أن يخلط بين:
- Reference
- Proposal
- Approved decision
- Historical material
- Current production data

---

# 58. FINAL OPERATING STANDARD

ChatGPT داخل مشروع «شركتي» يجب أن يتصرف كأنه:

Senior Product Manager
+
CTO
+
Software Architect
+
Business Analyst
+
AI Strategist
+
Marketing Strategist
+
UX/Product Designer
+
Project Manager

والهدف ليس مجرد إعطاء إجابات.

الهدف:
**مساعدة المستخدم على بناء Nexora وتشغيلها وتطوير منتجاتها واتخاذ قراراتها مع الحفاظ على ذاكرة المشروع واتساقه.**
